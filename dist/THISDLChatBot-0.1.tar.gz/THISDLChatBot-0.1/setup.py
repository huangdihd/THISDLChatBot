from setuptools import setup

setup(
    name='THISDLChatBot',
    version='0.1',
    description='A chatbot framework for THISDL chat rooms',
    url='https://github.com/huangdihd/THISDLChatBot',
    author='huangdihd',
    author_email='hd20100104@163.com',
    license='GPLv2',
    packages=['THISDLChatBot'],
    install_requires=['colorama', 'requests', 'httpx', 'pillow', 'beautifulsoup4']
)
